import React, { useState } from "react";
import { CareerTip } from "../types";

export const TIPS_DATA: CareerTip[] = [
  {
    id: "ats-bot",
    title: "Master the ATS-Bot",
    category: "SYSTEM COMPLIANCE",
    snippet: "Recruiters spend 6 seconds per resume. But the AI scans it in milliseconds. Use standard headings to ensure no experience is missed.",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCAvtEgjHRTCpBdJnsAI5w2AUhRxOy5EZ6p4_s0lpc6st_D6ya3b4PLzU5NioLniz9Tm6QEJEOdlmpkdVjykj64Zwy4LcICTNL3VAfErL_sXGha7SOUMKHDY6_xAW953FNSuEhRRMUXWzpXlFitti_6WXsiG3hfuQRbPWLZwakhuG9XaNk3YaPnQVHe_nas_r4Rej4hDu0E1R_oCCNTobjSjyrKCCnmcegu12xP2Y6RmcYXoor6qER54hzoG-kbtX7iXTlEvN3NFNas",
    content: `Almost 99% of Fortune 500 companies utilize automated Applicant Tracking Systems (ATS) to scan resumes before any recruiter sees them. Here is how you conquer them:

1. **Header Hygiene**: Never put critical text (like contact info) inside header or footer fields. Some parsers cannot extract them.
2. **Standard Section Names**: Use unambiguous section identifiers. Avoid fancy headers like "Where I've Been." Use literal standard titles like: "Professional Experience", "Skills", "Education".
3. **Keyword Density**: Align your resume with the target job spec. If they ask for "NodeJS microservices", do not write "JavaScript API developer" - use the exact phrasing.
4. **Clean Hierarchy**: Do not use tables, graphics, complex multi-column grids or custom vectors inside your uploaded files. Simple text flows better.`
  },
  {
    id: "passive-verbs",
    title: "Ditch 'Responsible For'",
    category: "COPY CLINIC",
    snippet: "Avoid passive filler speech. Replace weak words with high-impact, results-driven action verbs to establish strong ownership.",
    imageUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80",
    content: `When you write "Responsible for managing X", you sound like a passive observer following orders. You want to sound like an action-oriented driver.

Compare these:
- 🔴 *Passive*: "Responsible for building the user interface of React apps."
- 🟢 *Active*: "Architected and engineered core modules, achieving 40% loading improvements using React and profiling."

**High-Energy verbs to adopt:**
- **For Leadership**: Spearheaded, Orchestrated, Chaired, Governed, Directed, Propelled.
- **For Tech Creation**: Architected, Engineered, Formulated, Automated, Systematized, Refined.
- **For Growth/Metrics**: Multiplied, Boosted, Slashed, Maximized, Consolidated, Capitalized.`
  },
  {
    id: "metric-magic",
    title: "The XYZ Metric Formula",
    category: "IMPACT DESIGN",
    snippet: "Transform descriptive duties into absolute business impact. Learn Google's famous formula to frame achievements.",
    imageUrl: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=600&q=80",
    content: `Former Google recruiters popularized the XYZ achievement formula:

> **"Accomplished [X], as measured by [Y], by doing [Z]"**

Every single bullet point on your resume should answer these three metrics if possible.

- **The X**: What was the baseline result/goal? (e.g., "Boosted checkout speed")
- **The Y**: What was the quantitative metric proof? (e.g., "by 35%")
- **The Z**: What technologies or innovations did you deploy to get there? (e.g., "by rewriting the API routing structure and implementing Redis key-value caching").

Putting it together:
*"Lapsed customer drop-off decreased by 18% by formulating a targeted push-notification sequence using automated AWS triggers."*`
  }
];

export const TipsGuide: React.FC = () => {
  const [selectedTip, setSelectedTip] = useState<CareerTip | null>(null);

  return (
    <div className="space-y-8 animate-fade-in-up pb-12">
      {/* Featured Header */}
      <div className="text-center md:text-left mb-6 border-b border-[#1A1A1A]/10 pb-4">
        <span className="text-[10px] tracking-[0.2em] font-mono uppercase text-[#1A1A1A]/50 block mb-1">
          RECRUITER MANIFESTO / CURATED ARTIFACTS
        </span>
        <h2 className="font-display text-4xl text-[#1A1A1A] font-extrabold tracking-tight">
          Tips & Pro Insights
        </h2>
        <p className="text-[#1A1A1A]/70 text-sm max-w-lg mt-2">
          Expert articles from professional resume architects to get you past screening algorithms.
        </p>
      </div>

      <div className="space-y-6">
        {TIPS_DATA.map((tip) => (
          <div
            key={tip.id}
            className="bg-white border border-[#1A1A1A]/15 overflow-hidden flex flex-col md:flex-row transition-all hover:border-[#1A1A1A]/30"
          >
            <div className="md:w-1/3 h-48 md:h-auto overflow-hidden relative bg-stone-100 shrink-0">
              <img
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.03]"
                src={tip.imageUrl}
                alt={tip.title}
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-[#1A1A1A] text-[#FDFCFB] text-[8.5px] uppercase font-mono tracking-widest px-2.5 py-1">
                {tip.category}
              </div>
            </div>

            <div className="p-6 md:p-8 md:w-2/3 flex flex-col justify-between">
              <div>
                <span className="font-mono text-[9px] text-[#B8A380] font-bold mb-1.5 block tracking-widest">
                  PRO TIP OF THE WEEK
                </span>
                <h3 className="font-display text-2xl font-light italic text-[#1A1A1A] mb-3 leading-tight">
                  {tip.title}
                </h3>
                <p className="font-sans text-[#1A1A1A]/70 leading-relaxed text-xs sm:text-sm mb-6 font-light">
                  {tip.snippet}
                </p>
              </div>

              <button
                onClick={() => setSelectedTip(tip)}
                className="text-[#1A1A1A] hover:text-[#B8A380] font-mono text-[10px] uppercase font-medium tracking-widest flex items-center gap-2 group transition-colors self-start cursor-pointer hover:underline decoration-1"
              >
                Read Full Manuscript
                <span className="material-symbols-outlined text-sm transition-transform group-hover:translate-x-1">
                  trending_flat
                </span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Overlay Dialog Modal */}
      {selectedTip && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-[#1A1A1A]/60 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-white max-w-2xl w-full max-h-[85vh] overflow-y-auto border border-[#1A1A1A]/15 flex flex-col relative">
            
            {/* Modal Cover Image */}
            <div className="h-56 relative w-full overflow-hidden shrink-0 bg-stone-100">
              <img
                src={selectedTip.imageUrl}
                alt={selectedTip.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A] to-transparent flex items-end p-6">
                <div>
                  <span className="bg-[#B8A380] text-white text-[8px] uppercase font-mono tracking-widest px-2.5 py-1">
                    {selectedTip.category}
                  </span>
                  <h2 className="font-display text-2xl md:text-3xl font-light italic text-[#FDFCFB] mt-2 leading-tight">
                    {selectedTip.title}
                  </h2>
                </div>
              </div>
              
              {/* Close Button */}
              <button
                onClick={() => setSelectedTip(null)}
                className="absolute top-4 right-4 bg-white text-[#1A1A1A] w-9 h-9 flex items-center justify-center shadow-md hover:bg-stone-100 transition-colors cursor-pointer"
                title="Close"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 md:p-8 overflow-y-auto space-y-6 text-[#1A1A1A]/90">
              <p className="font-display italic text-[#1A1A1A] text-lg leading-relaxed border-l-2 border-[#1A1A1A] pl-4">
                {selectedTip.snippet}
              </p>
              
              <div className="prose prose-stone max-w-none text-xs sm:text-sm leading-relaxed text-[#1A1A1A]/85 whitespace-pre-wrap font-light">
                {selectedTip.content}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="border-t border-[#1A1A1A]/10 p-5 bg-[#F4F2EE]/40 flex justify-end shrink-0">
              <button
                onClick={() => setSelectedTip(null)}
                className="px-6 py-2 bg-[#1A1A1A] text-white font-mono text-[10px] uppercase tracking-widest hover:bg-[#2A2A2A] transition-all cursor-pointer"
              >
                Return to Sandbox
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
