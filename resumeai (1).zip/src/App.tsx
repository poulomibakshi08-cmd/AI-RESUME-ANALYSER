import React, { useState, useEffect } from "react";
import { ScoreGauge } from "./components/ScoreGauge";
import { ReviewComparison } from "./components/ReviewComparison";
import { TipsGuide } from "./components/TipsGuide";
import { AnalysisResult, SkillTag, ImpactPhrase } from "./types";

// Constant Default Resume Templates for instant, smooth testing
const SAMPLE_RESUMES = {
  frontend: {
    targetRole: "Senior Frontend Developer",
    resumeText: `Jordan Smith
Senior Frontend Developer | jordan.smith@email.com
Key Achievements:
- Responsible for building the user interface of various web applications using React and CSS.
- Maintained legacy system tables, designed homepages, and performed weekly code pushes.
- I was in charge of helping clean up our Redux store patterns because they were slow.
- Added some basic testing features for client components.`,
  },
  backend: {
    targetRole: "Senior Backend Engineer",
    resumeText: `Alex Rivers
Alex Rivers - Software Engineer | alex.rivers@db.io
Key Achievements:
- Wrote the API endpoints and did maintenance on SQL tables.
- Helped make our database queries slightly faster when we had peak traffic.
- Wrote Python and Node script lines to read log backups.
- Participated in standups and did general support when things crashed.`,
  },
  designer: {
    targetRole: "Lead Product Designer",
    resumeText: `Taylor Frost
Lead UX/UI Designer | taylor.frost@pixel.com
Key Achievements:
- Maintained and designed some page templates and did custom banners.
- Responsible for sketching page structures in Figma based on specifications.
- Talked to clients about their feedback and fixed styling issues.
- Optimized image files in order to save our site loading bandwidth.`,
  }
};

const DEFAULT_ANALYSIS: AnalysisResult = {
  id: "jordan-default",
  timestamp: new Date().toLocaleString(),
  targetRole: "Senior Frontend Developer",
  originalText: SAMPLE_RESUMES.frontend.resumeText,
  matchScore: 78,
  scoreCritique: "Solid work! You're above average for Senior Dev roles.",
  optimizedRole: "Frontend Architect",
  optimizedContent: "Architected and engineered core modules for high-traffic web platforms, achieving a 40% reduction in page load time using React 18, Vite, and custom performance profiling.",
  critiqueText: "'Responsible for' and 'Wrote code' are passive phrases. Needs more quantitative impact data and metrics.",
  improvementBadge: "Upgraded title to 'Architect'. Added metrics and high-impact action verbs.",
  impactPhrases: [
    { type: "good", text: `"Led architectural redesign" is high impact!` },
    { type: "passive", text: `"Responsible for coding" is too passive. Try "Engineered core modules".` }
  ],
  skillsRadar: [
    { name: "REACT.JS", status: "match" },
    { name: "TYPESCRIPT", status: "match" },
    { name: "DOCKER", status: "match" },
    { name: "AWS LACKING", status: "lacking" },
    { name: "REDIS LACKING", status: "lacking" }
  ]
};

export default function App() {
  const [activeTab, setActiveTab] = useState<"analyze" | "history" | "tips">("analyze");
  const [targetRole, setTargetRole] = useState<string>("Senior Frontend Developer");
  const [resumeText, setResumeText] = useState<string>(SAMPLE_RESUMES.frontend.resumeText);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStatus, setAnalysisStatus] = useState<string>("");
  
  const [currentResult, setCurrentResult] = useState<AnalysisResult>(DEFAULT_ANALYSIS);
  const [historyList, setHistoryList] = useState<AnalysisResult[]>([]);
  
  // Interactive PDF/Text Download Modal
  const [isExportingPDF, setIsExportingPDF] = useState<boolean>(false);
  
  // Interactive GitHub deployment modal
  const [isGithubModalOpen, setIsGithubModalOpen] = useState<boolean>(false);
  const [githubUsername, setGithubUsername] = useState<string>("octocat");
  const [githubRepoName, setGithubRepoName] = useState<string>("resumeai-optimized");
  const [githubStatus, setGithubStatus] = useState<string>("");
  const [githubStep, setGithubStep] = useState<number>(0); // 0=idle, 1=auth, 2=creating repo, 3=commit, 4=success

  // Handle Drag & Drop simulated state
  const [isDragActive, setIsDragActive] = useState<boolean>(false);

  // Load history from localStorage once on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("resumeai_history_v2");
      if (stored) {
        setHistoryList(JSON.parse(stored));
      } else {
        // Seed initial history
        setHistoryList([DEFAULT_ANALYSIS]);
        localStorage.setItem("resumeai_history_v2", JSON.stringify([DEFAULT_ANALYSIS]));
      }
    } catch (e) {
      console.warn("Storage item cannot be read:", e);
    }
  }, []);

  // Quick select dynamic templates
  const handleSelectTemplate = (type: "frontend" | "backend" | "designer") => {
    const template = SAMPLE_RESUMES[type];
    setTargetRole(template.targetRole);
    setResumeText(template.resumeText);
  };

  // Perform full-stack analysis using Express backend
  const handleRunAnalysis = async () => {
    if (!resumeText.trim()) return;
    setIsAnalyzing(true);
    setAnalysisStatus("Ingesting resume telemetry...");

    // Stagger loading progress to make the AI feel sophisticated and responsive
    const steps = [
      "Parsing lexical keywords...",
      "Matching industry benchmarks...",
      "Refructuring passive statements...",
      "Evaluating skills matrices with Gemini..."
    ];

    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < steps.length) {
        setAnalysisStatus(steps[stepIndex]);
        stepIndex++;
      }
    }, 600);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resumeText,
          targetRole
        })
      });

      if (!response.ok) {
        throw new Error("Failed to optimize resume language with server");
      }

      const rawResult = await response.json();
      
      const enrichedResult: AnalysisResult = {
        id: `analysis-${Date.now()}`,
        timestamp: new Date().toLocaleString(),
        targetRole,
        originalText: resumeText,
        matchScore: rawResult.matchScore || 75,
        scoreCritique: rawResult.scoreCritique || "Optimization recommendations ready.",
        optimizedRole: rawResult.optimizedRole || "Optimized Specialist",
        optimizedContent: rawResult.optimizedContent || resumeText,
        critiqueText: rawResult.critiqueText || "Identified soft structure elements.",
        improvementBadge: rawResult.improvementBadge || "Added metric parameters.",
        impactPhrases: rawResult.impactPhrases || [],
        skillsRadar: rawResult.skillsRadar || []
      };

      // Set state and save to local persistence history
      setCurrentResult(enrichedResult);
      const updatedHistory = [enrichedResult, ...historyList.filter(item => item.id !== "jordan-default")];
      setHistoryList(updatedHistory);
      localStorage.setItem("resumeai_history_v2", JSON.stringify(updatedHistory));
      
      // Auto transition view
      window.scrollTo({ top: 300, behavior: "smooth" });

    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Something went wrong in communication. Please check your credentials.");
    } finally {
      clearInterval(interval);
      setIsAnalyzing(false);
      setAnalysisStatus("");
    }
  };

  // Download simulation files
  const handleDownloadFile = () => {
    const fileHeader = `RESUMEAI OPTIMIZED RESUME SHEET\n`;
    const sectionSeparator = `\n==========================================\n`;
    const fileContent = `${fileHeader}${sectionSeparator}RECOMMENDED TITLE: ${currentResult.optimizedRole}\n\nOPTIMIZED RESUME CONTENT:\n${currentResult.optimizedContent}\n${sectionSeparator}ATS SCORE: ${currentResult.matchScore}/100\nCRITIQUE NOTES: ${currentResult.critiqueText}\n\nSKILLS INCLUDED:\n${currentResult.skillsRadar.map(s => ` - ${s.name} [${s.status.toUpperCase()}]`).join("\n")}\n${sectionSeparator}SAVED TIMESTAMP: ${currentResult.timestamp}\n`;
    
    const blob = new Blob([fileContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `optimized-cv-${currentResult.optimizedRole.toLowerCase().replace(/[^a-z0-9]/g, "-")}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    // Feedback dialog
    setIsExportingPDF(true);
  };

  // simulated GitHub commit progress
  const handleExportToGithub = () => {
    setGithubStep(1);
    setGithubStatus("Authenticating OAuth flow...");
    
    setTimeout(() => {
      setGithubStep(2);
      setGithubStatus(`Provisioning repository: github.com/${githubUsername}/${githubRepoName}...`);
      
      setTimeout(() => {
        setGithubStep(3);
        setGithubStatus(`Pushing optimized files: resume.md and config.json to master branch...`);
        
        setTimeout(() => {
          setGithubStep(4);
          setGithubStatus("Export complete! Swapped master commits securely.");
        }, 1200);
      }, 1000);
    }, 800);
  };

  // Drag and drop interaction
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(true);
  };

  const handleDragLeave = () => {
    setIsDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setResumeText(event.target.result as string);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="min-h-screen pb-36 text-[#1A1A1A] bg-[#FDFCFB] flex flex-col items-center">
      
      {/* Translucent Editorial Top App Bar */}
      <header className="fixed top-0 w-full z-40 flex items-center justify-between px-6 sm:px-12 py-4 bg-[#FDFCFB]/90 backdrop-blur-md border-b border-[#1A1A1A]/10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-[#1A1A1A] flex items-center justify-center text-white">
            <span className="material-symbols-outlined select-none text-[18px]">
              fingerprint
            </span>
          </div>
          <h1 className="font-display text-2xl font-light italic tracking-tight text-[#1A1A1A]">
            ResumeAI
          </h1>
          <span className="text-[9px] bg-[#E8E6E1] text-[#1A1A1A] px-2 py-0.5 font-mono uppercase tracking-widest hidden sm:inline-block">
            EDITION V3.5
          </span>
        </div>

        {/* Live Status Indicator & Exit Button */}
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 bg-[#E8E6E1]/50 text-[#1A1A1A]/80 px-3 py-1 text-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
            <span className="font-mono text-[9px] uppercase tracking-widest font-medium">
              Systems Sync Ready
            </span>
          </div>

          <a 
            href="#" 
            onClick={() => {
              if (confirm("Are you sure you want to return to default values? This clears local changes.")) {
                localStorage.removeItem("resumeai_history_v2");
                window.location.reload();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1 bg-white text-[#1A1A1A] hover:bg-stone-50 transition-all text-xs font-mono uppercase tracking-wider border border-[#1A1A1A]/20"
          >
            <span className="material-symbols-outlined text-[14px]">refresh</span>
            <span>Reset Engine</span>
          </a>
        </div>
      </header>

      {/* Main Container */}
      <main className="w-full max-w-4xl px-4 mt-24 flex-1">
        
        {/* TAB 1: ANALYZE AND WORKSPACE SCREEN */}
        {activeTab === "analyze" && (
          <div className="space-y-8 animate-fade-in-up">
            
            {/* Elegant Hero Slogan */}
            <section className="text-center py-6">
              <h2 className="font-display text-4xl sm:text-5xl md:text-6xl text-[#1A1A1A] font-light italic tracking-tight leading-none mb-3">
                Optimize Your Career
              </h2>
              <p className="font-sans text-xs sm:text-sm text-[#1A1A1A]/70 max-w-lg mx-auto font-light leading-relaxed">
                A pristine, metric-driven language pipeline carefully engineered to bypass automated corporate filters.
              </p>
            </section>

            {/* Dashboard Score card + Toggle Display */}
            <div className="space-y-6">
              
              {/* Review Toggle Comparisons */}
              <ReviewComparison currentResult={currentResult} />

              {/* Bento Grid Results metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Gauge Metric Indicator */}
                <ScoreGauge 
                  score={currentResult.matchScore} 
                  critique={currentResult.scoreCritique} 
                />

                {/* Impact Phrases List Card */}
                <div className="bg-white border border-[#1A1A1A]/15 p-6 relative flex flex-col justify-between">
                  {/* Decorative bracket lines */}
                  <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-[#1A1A1A]/20" />
                  <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-[#1A1A1A]/20" />
                  
                  <div>
                    <div className="flex items-center gap-2 mb-4 border-b border-[#1A1A1A]/10 pb-2">
                      <span className="material-symbols-outlined text-[#1A1A1A] text-lg select-none">
                        bolt
                      </span>
                      <h4 className="font-display text-lg font-light italic text-[#1A1A1A]">
                        Verbal Power Audits
                      </h4>
                    </div>
                    
                    <ul className="space-y-3.5">
                      {currentResult.impactPhrases && currentResult.impactPhrases.length > 0 ? (
                        currentResult.impactPhrases.map((phrase, i) => (
                          <li key={i} className="flex items-start gap-2.5">
                            {phrase.type === "good" ? (
                              <>
                                <span className="material-symbols-outlined text-emerald-600 text-[18px] select-none shrink-0 mt-0.5">
                                  check_circle
                                </span>
                                <p className="text-xs sm:text-sm font-light text-[#1A1A1A] leading-relaxed">
                                  {phrase.text}
                                </p>
                              </>
                            ) : (
                              <>
                                <span className="material-symbols-outlined text-amber-600 text-[18px] select-none shrink-0 mt-0.5">
                                  info
                                </span>
                                <p className="text-xs sm:text-sm font-light text-[#1A1A1A]/70 leading-relaxed italic">
                                  {phrase.text}
                                </p>
                              </>
                            )}
                          </li>
                        ))
                      ) : (
                        <p className="text-xs text-stone-400 font-mono">No phrases analyzed yet.</p>
                      )}
                    </ul>
                  </div>

                  {/* Quick Export Panel buttons */}
                  <div className="mt-6 pt-4 border-t border-[#1A1A1A]/10 space-y-3">
                    <button 
                      onClick={handleDownloadFile}
                      className="w-full bg-[#1A1A1A] hover:bg-[#2A2A2A] text-white py-3 font-mono text-[10px] tracking-widest uppercase transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-sm">download</span>
                      Download Resume Sheet (TXT)
                    </button>

                    <div className="p-3 bg-stone-50 border border-[#1A1A1A]/10 flex flex-col gap-2">
                      <h5 className="font-mono text-[8.5px] text-[#1A1A1A]/60 font-bold tracking-widest uppercase flex items-center gap-1">
                        <span className="material-symbols-outlined text-[12px]">share</span>
                        PERSIST TO PORTFOLIO
                      </h5>
                      <button 
                        onClick={() => {
                          setIsGithubModalOpen(true);
                          setGithubStep(0);
                        }}
                        className="w-full bg-[#E8E6E1]/50 border border-[#1A1A1A]/20 hover:bg-[#1A1A1A] hover:text-white hover:border-[#1A1A1A] text-[#1A1A1A] py-2 font-mono text-[9px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all cursor-pointer"
                      >
                        <svg className="w-3.5 h-3.5 fill-current shrink-0" viewBox="0 0 24 24">
                          <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.041-1.412-4.041-1.412-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"></path>
                        </svg>
                        <span>Export to GitHub</span>
                      </button>
                      <p className="text-[8.5px] text-center text-[#1A1A1A]/50 font-mono tracking-tight leading-normal">
                        Simulate production commits securely to public branches
                      </p>
                    </div>
                  </div>
                </div>

                {/* Skills Gap radar card */}
                <div className="bg-white border border-[#1A1A1A]/15 p-6 relative md:col-span-2">
                  <div className="absolute top-0 right-0 w-2.5 h-2.5 border-t border-r border-[#1A1A1A]/20" />
                  <div className="absolute bottom-0 left-0 w-2.5 h-2.5 border-b border-l border-[#1A1A1A]/20" />

                  <div className="flex items-center gap-2 mb-4 border-b border-[#1A1A1A]/10 pb-2">
                    <span className="material-symbols-outlined text-[#1A1A1A] text-lg select-none">
                      grain
                    </span>
                    <h4 className="font-display text-lg font-light italic text-[#1A1A1A]">
                      Keywords & Skills Audit
                    </h4>
                  </div>
                  <p className="text-xs text-[#1A1A1A]/70 font-light mb-4 leading-relaxed">
                    A machine parsing assessment of high-density domain tags flagged in target descriptors versus current input:
                  </p>
                  
                  <div className="flex flex-wrap gap-2">
                    {currentResult.skillsRadar && currentResult.skillsRadar.length > 0 ? (
                      currentResult.skillsRadar.map((skill, index) => (
                        <div
                          key={index}
                          className={`px-3 py-1.5 font-mono text-[10px] tracking-wider flex items-center gap-2 transition-all ${
                            skill.status === "match"
                              ? "bg-[#1A1A1A] text-[#FDFCFB]"
                              : "bg-[#E8E6E1]/50 text-[#1A1A1A] border border-[#1A1A1A]/10"
                          }`}
                        >
                          <span className={`w-1 h-1 ${skill.status === "match" ? "bg-emerald-400" : "bg-[#B8A380]"} shrink-0`} />
                          <span>{skill.name}</span>
                          <span className={`text-[8px] tracking-normal px-1 ${skill.status === "match" ? "bg-white/10 text-white" : "bg-black/5 text-[#1A1A1A]"} uppercase font-sans font-bold`}>
                            {skill.status === "match" ? "MATCH" : "LACK"}
                          </span>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-stone-400 font-mono">No skills keywords identified.</p>
                    )}
                  </div>
                </div>

              </div>

            </div>

            {/* Dynamic Custom Customizer Submission / Input workspace */}
            <section 
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`bg-white border p-6 sm:p-8 transition-all duration-300 relative ${
                isDragActive 
                  ? "border-[#1A1A1A] bg-[#F4F2EE] scale-[1.01]" 
                  : "border-dashed border-[#1A1A1A]/20"
              }`}
            >
              <div className="absolute top-4 right-4 bg-[#1A1A1A] text-white text-[8px] uppercase font-mono tracking-widest px-2.5 py-1">
                Workspace Setup
              </div>

              <div className="flex flex-col items-center justify-center text-center max-w-xl mx-auto mb-6">
                <div className="w-12 h-12 bg-[#E8E6E1]/50 text-[#1A1A1A] flex items-center justify-center mb-4">
                  <span className="material-symbols-outlined text-2xl select-none">
                    cloud_upload
                  </span>
                </div>
                <h3 className="font-display text-xl font-light italic text-[#1A1A1A] mb-1">
                  Upload Resume / Paste Text
                </h3>
                <p className="font-sans text-xs text-[#1A1A1A]/60 font-light leading-relaxed">
                  Provide copy, standard Markdown text, or drop a raw TXT file directly.
                </p>
              </div>

              {/* Sample Profile Selectors */}
              <div className="mb-6 flex flex-wrap items-center justify-center gap-2.5">
                <span className="text-[9px] text-[#1A1A1A]/50 font-mono uppercase font-bold tracking-widest shrink-0 mr-1">
                  Sandbox Presets:
                </span>
                <button
                  onClick={() => handleSelectTemplate("frontend")}
                  className="px-3 py-1.5 bg-[#E8E6E1]/40 border border-[#1A1A1A]/10 hover:bg-[#1A1A1A] hover:text-[#FDFCFB] hover:border-[#1A1A1A] font-mono text-[9px] uppercase tracking-widest transition-all text-left cursor-pointer flex items-center gap-1"
                >
                  <span className="material-symbols-outlined text-[13px]">code</span>
                  Frontend Dev
                </button>
                <button
                  onClick={() => handleSelectTemplate("backend")}
                  className="px-3 py-1.5 bg-[#E8E6E1]/40 border border-[#1A1A1A]/10 hover:bg-[#1A1A1A] hover:text-[#FDFCFB] hover:border-[#1A1A1A] font-mono text-[9px] uppercase tracking-widest transition-all text-left cursor-pointer flex items-center gap-1"
                >
                  <span className="material-symbols-outlined text-[13px]">dns</span>
                  Backend Eng
                </button>
                <button
                  onClick={() => handleSelectTemplate("designer")}
                  className="px-3 py-1.5 bg-[#E8E6E1]/40 border border-[#1A1A1A]/10 hover:bg-[#1A1A1A] hover:text-[#FDFCFB] hover:border-[#1A1A1A] font-mono text-[9px] uppercase tracking-widest transition-all text-left cursor-pointer flex items-center gap-1"
                >
                  <span className="material-symbols-outlined text-[13px]">palette</span>
                  Designer
                </button>
              </div>

              {/* Dynamic Workspace Fields */}
              <div className="space-y-4">
                
                {/* Target Role input field */}
                <div>
                  <label className="block text-[9px] font-mono font-bold uppercase tracking-widest text-[#1A1A1A]/60 mb-2">
                    Target Career Position Description
                  </label>
                  <input
                    type="text"
                    value={targetRole}
                    onChange={(e) => setTargetRole(e.target.value)}
                    placeholder="e.g. Senior Frontend Architect, Staff System Operator"
                    className="w-full bg-[#FDFCFB] border border-[#1A1A1A]/15 focus:border-[#1A1A1A] focus:ring-1 focus:ring-[#1A1A1A]/10 outline-none px-4 py-3 text-sm font-light transition-all text-[#1A1A1A]"
                  />
                </div>

                {/* Resume textarea */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-[9px] font-mono font-bold uppercase tracking-widest text-[#1A1A1A]/60">
                      Your Current Resume Draft
                    </label>
                    <span className="text-[9px] font-mono text-[#1A1A1A]/40">
                      {resumeText ? resumeText.length : 0} glyphs
                    </span>
                  </div>
                  <textarea
                    rows={6}
                    value={resumeText}
                    onChange={(e) => setResumeText(e.target.value)}
                    placeholder="Paste or write your resume summary, achievements list, and skillset items..."
                    className="w-full bg-[#FDFCFB] border border-[#1A1A1A]/15 focus:border-[#1A1A1A] focus:ring-1 focus:ring-[#1A1A1A]/10 outline-none px-4 py-3 text-xs sm:text-sm font-mono leading-relaxed transition-all resize-y text-[#1A1A1A]"
                  />
                </div>

                {/* Analysis CTA Button */}
                <button
                  onClick={handleRunAnalysis}
                  disabled={isAnalyzing || !resumeText.trim()}
                  className="w-full py-3.5 bg-[#1A1A1A] hover:bg-[#2A2A2A] text-white font-mono text-[11px] uppercase tracking-[0.2em] transition-all disabled:opacity-50 active:translate-y-px cursor-pointer flex items-center justify-center gap-2 text-center shadow-sm"
                >
                  <span>Trigger Evaluation Pipeline</span>
                  <span className="material-symbols-outlined text-sm">
                    pageview
                  </span>
                </button>

              </div>
            </section>

            {/* Simulated Pro Tip Footer widget */}
            <div className="mt-6 border border-[#1A1A1A]/15 bg-white overflow-hidden">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/3 h-48 md:h-auto overflow-hidden bg-stone-100">
                  <img 
                    className="w-full h-full object-cover grayscale opacity-90 hover:grayscale-0 transition-all duration-700" 
                    alt="Futuristic Neon Workspace" 
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCAvtEgjHRTCpBdJnsAI5w2AUhRxOy5EZ6p4_s0lpc6st_D6ya3b4PLzU5NioLniz9Tm6QEJEOdlmpkdVjykj64Zwy4LcICTNL3VAfErL_sXGha7SOUMKHDY6_xAW953FNSuEhRRMUXWzpXlFitti_6WXsiG3hfuQRbPWLZwakhuG9XaNk3YaPnQVHe_nas_r4Rej4hDu0E1R_oCCNTobjSjyrKCCnmcegu12xP2Y6RmcYXoor6qER54hzoG-kbtX7iXTlEvN3NFNas"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-6 md:p-8 md:w-2/3 flex flex-col justify-between">
                  <div>
                    <span className="font-mono text-[9px] font-bold text-[#B8A380] mb-1.5 block tracking-widest leading-none">
                      PRO TIP OF THE DAY
                    </span>
                    <h3 className="font-display text-2xl font-light italic text-[#1A1A1A] mb-3 leading-tight">
                      Master the ATS-Bot
                    </h3>
                    <p className="font-sans text-[#1A1A1A]/70 text-xs sm:text-sm leading-relaxed mb-6 font-light">
                      Recruiters spend 6 seconds per resume. But the AI scans it in milliseconds. Use standard headings to ensure no experience is missed.
                    </p>
                  </div>
                  <button 
                    onClick={() => setActiveTab("tips")}
                    className="text-[#1A1A1A] hover:text-[#B8A380] font-mono text-[10px] uppercase font-semibold tracking-widest flex items-center gap-2 hover:translate-x-1 transition-all cursor-pointer self-start border-b border-[#1A1A1A]/10 pb-0.5"
                  >
                    Read full guides checklist
                    <span className="material-symbols-outlined text-sm">trending_flat</span>
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: PERSISTED HISTORY LOGS */}
        {activeTab === "history" && (
          <div className="space-y-8 animate-fade-in-up pb-12">
            <div className="text-center md:text-left mb-6 border-b border-[#1A1A1A]/10 pb-4">
              <span className="text-[10px] tracking-[0.2em] font-mono uppercase text-[#1A1A1A]/50 block mb-1">
                ARCHIVED EVALUATIONS
              </span>
              <h2 className="font-display text-4xl text-[#1A1A1A] font-extrabold tracking-tight">
                Evaluation History
              </h2>
              <p className="text-[#1A1A1A]/70 text-xs sm:text-sm font-light max-w-lg mt-2">
                Browse through previous analysis drafts, review ATS match ratings, and load target metrics instantly.
              </p>
            </div>

            <div className="space-y-4">
              {historyList.length > 0 ? (
                historyList.map((item) => (
                  <div
                    key={item.id}
                    className="border border-[#1A1A1A]/12 bg-white p-5 sm:p-6 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 relative"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[9px] font-mono text-[#FDFCFB] font-bold bg-[#1A1A1A] px-2 py-0.5">
                          SCORE: {item.matchScore}
                        </span>
                        <span className="text-[9px] font-mono text-[#1A1A1A]/50 font-light">
                          {item.timestamp}
                        </span>
                      </div>
                      <h4 className="font-display text-lg font-light text-[#1A1A1A]">
                        {item.targetRole} &rarr; <span className="italic block sm:inline font-normal">{item.optimizedRole}</span>
                      </h4>
                      <p className="text-xs text-[#1A1A1A]/60 line-clamp-1 max-w-xl font-light">
                        "{item.optimizedContent}"
                      </p>
                    </div>

                    <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
                      <button
                        onClick={() => {
                          setCurrentResult(item);
                          setTargetRole(item.targetRole);
                          setResumeText(item.originalText);
                          setActiveTab("analyze");
                          window.scrollTo({ top: 300, behavior: "smooth" });
                        }}
                        className="px-3.5 py-1.5 bg-[#1A1A1A] hover:bg-[#333333] text-white text-[10px] font-mono uppercase tracking-widest active:translate-y-px transition-all cursor-pointer"
                      >
                        Restore Result
                      </button>
                      
                      {item.id !== "jordan-default" && (
                        <button
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this log file?")) {
                              const filtered = historyList.filter(x => x.id !== item.id);
                              setHistoryList(filtered);
                              localStorage.setItem("resumeai_history_v2", JSON.stringify(filtered));
                            }
                          }}
                          className="w-8 h-8 bg-[#E8E6E1]/40 border border-[#1A1A1A]/10 hover:bg-stone-100 text-[#1A1A1A] flex items-center justify-center transition-all cursor-pointer"
                          title="Delete history item"
                        >
                          <span className="material-symbols-outlined text-sm">delete</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="border border-dashed border-[#1A1A1A]/20 p-8 text-center text-[#1A1A1A]/70 max-w-md mx-auto">
                  <span className="material-symbols-outlined text-4xl text-[#1A1A1A]/40 block mb-3">
                    calendar_today
                  </span>
                  <h3 className="font-display text-lg font-light italic text-[#1A1A1A] mb-1">
                    No Records Logged
                  </h3>
                  <p className="text-xs font-light text-[#1A1A1A]/60 mb-6 leading-relaxed">
                    Submit a copy of your draft resume profile in the main workspace to begin tracking your records.
                  </p>
                  <button
                    onClick={() => setActiveTab("analyze")}
                    className="px-4 py-2 bg-[#1A1A1A] text-white text-[10px] font-mono uppercase tracking-widest cursor-pointer hover:bg-stone-800"
                  >
                    Submit a Resume
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: MASTER RESUME GUIDES AND INSIGHTS */}
        {activeTab === "tips" && <TipsGuide />}

      </main>

      {/* Floating Bottom Navigation Tab Bar */}
      <nav className="fixed bottom-0 left-0 right-0 w-full z-40 bg-[#FDFCFB] border-t border-[#1A1A1A]/10 py-3 px-6 flex justify-center">
        <div className="flex justify-around items-center w-full max-w-md gap-4">
          
          {/* Main Analyze Tab button */}
          <button
            onClick={() => setActiveTab("analyze")}
            className={`flex flex-col items-center justify-center px-5 py-1 transition-all duration-200 cursor-pointer ${
              activeTab === "analyze"
                ? "text-[#1A1A1A] font-bold border-b-2 border-[#1A1A1A]"
                : "text-[#1A1A1A]/50 hover:text-[#1A1A1A]"
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">
              description
            </span>
            <span className="font-mono text-[9px] tracking-widest mt-0.5 block uppercase">
              Analyze
            </span>
          </button>

          {/* History Tab button */}
          <button
            onClick={() => setActiveTab("history")}
            className={`flex flex-col items-center justify-center px-5 py-1 transition-all duration-200 cursor-pointer ${
              activeTab === "history"
                ? "text-[#1A1A1A] font-bold border-b-2 border-[#1A1A1A]"
                : "text-[#1A1A1A]/50 hover:text-[#1A1A1A]"
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">
              history
            </span>
            <span className="font-mono text-[9px] tracking-widest mt-0.5 block uppercase">
              History
            </span>
          </button>

          {/* Tips Tab button */}
          <button
            onClick={() => setActiveTab("tips")}
            className={`flex flex-col items-center justify-center px-5 py-1 transition-all duration-200 cursor-pointer ${
              activeTab === "tips"
                ? "text-[#1A1A1A] font-bold border-b-2 border-[#1A1A1A]"
                : "text-[#1A1A1A]/50 hover:text-[#1A1A1A]"
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">
              lightbulb
            </span>
            <span className="font-mono text-[9px] tracking-widest mt-0.5 block uppercase">
              Tips
            </span>
          </button>

        </div>
      </nav>

      {/* DETAILED INTERACTIVE GITHUB OVERLAY PANEL */}
      {isGithubModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in-up">
          <div className="bg-white max-w-md w-full shadow-xl border border-[#1A1A1A]/10 rounded-none">
            
            <div className="bg-[#1A1A1A] p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.041-1.412-4.041-1.412-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"></path>
                </svg>
                <span className="font-display text-base font-light italic">Export Repository Draft</span>
              </div>
              <button 
                onClick={() => setIsGithubModalOpen(false)}
                className="text-white hover:text-stone-300 transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <div className="p-6 space-y-4">
              {githubStep === 0 ? (
                <>
                  <p className="text-xs text-[#1A1A1A]/70 font-light leading-relaxed">
                    Initiate a commit sequence to persist your optimized markdown index and analysis profiles directly into a designated repository branch.
                  </p>
                  
                  <div>
                    <label className="block text-[9px] font-mono font-bold uppercase text-[#1A1A1A]/50 mb-1.5">
                      GitHub Username Reference
                    </label>
                    <input 
                      type="text" 
                      value={githubUsername} 
                      onChange={(e) => setGithubUsername(e.target.value)}
                      className="w-full bg-[#FDFCFB] border border-[#1A1A1A]/20 outline-none px-3 py-2 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono font-bold uppercase text-[#1A1A1A]/50 mb-1.5">
                      Destination Repository Name
                    </label>
                    <input 
                      type="text" 
                      value={githubRepoName} 
                      onChange={(e) => setGithubRepoName(e.target.value)}
                      className="w-full bg-[#FDFCFB] border border-[#1A1A1A]/20 outline-none px-3 py-2 text-xs font-mono"
                    />
                  </div>

                  <button
                    onClick={handleExportToGithub}
                    className="w-full py-2.5 bg-[#1A1A1A] hover:bg-stone-800 text-white text-[10px] font-mono uppercase tracking-widest transition-all mt-4 cursor-pointer"
                  >
                    Authenticate and Push Draft
                  </button>
                </>
              ) : (
                <div className="text-center py-6 space-y-4">
                  {githubStep < 4 ? (
                    <div className="w-10 h-10 border-2 border-stone-100 border-t-[#1A1A1A] rounded-full animate-spin mx-auto mb-2" />
                  ) : (
                    <div className="w-10 h-10 bg-[#E8E6E1] flex items-center justify-center text-[#1A1A1A] mx-auto mb-2">
                      <span className="material-symbols-outlined text-xl">done</span>
                    </div>
                  )}

                  <p className="text-[9px] font-bold uppercase tracking-widest text-[#B8A380] font-mono mb-1">
                    Export State Tracker
                  </p>
                  <p className="text-xs text-[#1A1A1A]/80 max-w-xs mx-auto leading-relaxed">
                    {githubStatus}
                  </p>

                  {githubStep === 4 && (
                    <div className="pt-4 space-y-3">
                      <div className="p-3 bg-[#E8E6E1]/30 border border-[#1A1A1A]/10 text-xs font-light text-[#1A1A1A]">
                        Repository synchronized! Target URL: <span className="font-mono font-bold underline">github.com/{githubUsername}/{githubRepoName}</span>
                      </div>
                      <button
                        onClick={() => setIsGithubModalOpen(false)}
                        className="px-5 py-2 bg-[#1A1A1A] text-white text-[10px] font-mono uppercase tracking-widest hover:bg-[#333333] transition-all cursor-pointer"
                      >
                        Return to Workstation
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* EXPORTED EXCEL/PDF PREVIEW SHEET IF DOWNLOADED */}
      {isExportingPDF && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in-up">
          <div className="bg-[#FDFCFB] max-w-xl w-full max-h-[85vh] overflow-hidden flex flex-col shadow-xl border border-[#1A1A1A]/15 rounded-none">
            <div className="bg-[#1A1A1A] p-5 text-white flex justify-between items-center shrink-0">
              <h3 className="font-display text-lg font-light italic flex items-center gap-1.5">
                <span className="material-symbols-outlined select-none">verified_user</span>
                Resume Optimizations Exporter
              </h3>
              <button 
                onClick={() => setIsExportingPDF(false)}
                className="text-white hover:text-stone-300 transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4">
              <p className="text-xs text-[#1A1A1A]/70 font-light leading-relaxed">
                Your high-density resume representation has been generated as a standard copyable TXT ledger file for optimal machine-readability on typical application tracking platforms.
              </p>

              <div className="bg-stone-50 border border-[#1A1A1A]/10 p-4 font-mono text-[10px] text-[#1A1A1A] max-h-72 overflow-y-auto space-y-2 select-all">
                <p className="font-bold border-b border-[#1A1A1A]/10 pb-1 text-xs">{currentResult.optimizedRole}</p>
                <p className="leading-relaxed whitespace-pre-wrap">{currentResult.optimizedContent}</p>
                <p className="text-[#1A1A1A]/40 mt-4 pt-3 border-t border-[#1A1A1A]/10 uppercase tracking-widest text-[8px]">ATS Assessment: {currentResult.matchScore}/100 Confidence Index</p>
              </div>

              <div className="p-3 bg-[#E8E6E1]/30 border border-[#1A1A1A]/10 text-[9px] text-[#1A1A1A]/70 font-mono uppercase tracking-wide leading-relaxed flex items-start gap-2">
                <span className="material-symbols-outlined text-sm shrink-0">info</span>
                <span>Protip: Copy or save as plaintext, upload directly to corporate portals, or save to .pdf inside Word/Docs for automated filters.</span>
              </div>
            </div>

            <div className="p-5 bg-stone-50 border-t border-[#1A1A1A]/10 flex justify-end shrink-0">
              <button
                onClick={() => setIsExportingPDF(false)}
                className="px-5 py-2 bg-[#1A1A1A] text-white font-mono text-[10px] uppercase tracking-widest hover:bg-[#333333] transition-all cursor-pointer"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ANALYSIS FULL INTERACTIVE METRICS WORKSPACE OVERLAY */}
      {isAnalyzing && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#FDFCFB]/95 backdrop-blur-xs text-[#1A1A1A] select-none">
          <div className="relative w-16 h-16 mb-8 flex items-center justify-center">
            <div className="absolute inset-0 border border-stone-200" />
            <div className="absolute inset-0 border-t-2 border-r-2 border-[#1A1A1A] animate-spin" />
            <span className="material-symbols-outlined text-2xl text-[#1A1A1A]">
              hourglass_empty
            </span>
          </div>
          
          <h3 className="font-display text-2xl font-light italic mb-2 text-[#1A1A1A] animate-pulse">
            Analyzing Language Density
          </h3>
          <p className="text-[9px] font-mono font-bold tracking-[0.25em] text-[#1A1A1A]/50 uppercase">
            {analysisStatus || "Initializing parsing pipelines..."}
          </p>
        </div>
      )}

    </div>
  );
}
