export interface SkillTag {
  name: string;
  status: "match" | "lacking";
}

export interface ImpactPhrase {
  type: "good" | "passive";
  text: string;
}

export interface AnalysisResult {
  id: string;
  timestamp: string;
  targetRole: string;
  originalText: string;
  matchScore: number;
  scoreCritique: string;
  optimizedRole: string;
  optimizedContent: string;
  critiqueText: string;
  improvementBadge: string;
  impactPhrases: ImpactPhrase[];
  skillsRadar: SkillTag[];
}

export interface CareerTip {
  id: string;
  title: string;
  category: string;
  snippet: string;
  content: string;
  imageUrl: string;
}
